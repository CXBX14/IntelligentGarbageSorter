# Garbage Sorter > 2023-06-05 12:30am
https://universe.roboflow.com/intgarsor/garbage-sorter

Provided by a Roboflow user
License: CC BY 4.0

